<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>passing data with extract</title>
</head>
<body>
	<p>Extracted parameters from an associative array.</p>
<dl>
<dt>Date</dt>
<dd><?= $date ?></dd>
<dt>Timezone Type</dt>
<dd><?= $timezone_type ?></dd>
<dt>Timezone</dt>
<dd><?= $timezone ?></dd>
</dl>
</body>
</html>